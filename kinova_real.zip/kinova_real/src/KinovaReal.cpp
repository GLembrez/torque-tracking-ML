#include "KinovaReal.h"


KinovaReal::KinovaReal(mc_rbdyn::RobotModulePtr rm, double dt, const mc_rtc::Configuration & config)
: mc_control::MCController(rm, dt)
{
  /* 
  Initializes the mc-rtc controller, initialize control, creates the torch model from saved weights
  */


  /*  set up solver */
  solver().addConstraintSet(contactConstraint);
  solver().addConstraintSet(dynamicsConstraint);
  solver().addTask(postureTask);
  solver().setContacts({{}});
  postureTask->stiffness(0.5) ;
  postureTask->reset();

  /* set up control scheme  */ 
  alpha.setZero();
  stiction.setZero();
  cmdTau_filtered.setZero();
  acc_d.setZero();
  Kp.setZero();
  Kd.setZero();
  I.setZero();
  Kp.diagonal() << 100,100,100,100,20,20,20;
  Kd.diagonal() << 10,10,10,10,1,1,1;
  I.diagonal() << 19,19,19,19,15,15,15;
  maxTau << 55,55,55,55,22,22,22;
  Fs << 2.44,4.2,2.5,4.2,1.5,2,1.7 ;
  coriolis = new rbd::Coriolis(realRobot().mb()) ;

  /* set up loggers */ 
  for(int idx=0; idx<7; idx++)
  {
    logger().addLogEntry("cmdTau_" + std::to_string(idx), this, [this,idx]() { return cmdTau[idx]; });          // desired torque
    logger().addLogEntry("C_" + std::to_string(idx), this, [this,idx]() { return C[idx]; });                    // gravity - coriolis centrifugal vector
    logger().addLogEntry("r_" + std::to_string(idx), this, [this,idx]() { return -r[idx]; });                   // residual from generalized momentum
    logger().addLogEntry("measE_" + std::to_string(idx), this, [this,idx]() { return measured_error[idx]; });   // error from torque sensors
    logger().addLogEntry("predE_" + std::to_string(idx), this, [this,idx]() { return predicted_error[idx]; });  // error from model
    logger().addLogEntry("stictionVel_" + std::to_string(idx), this, [this,idx]() { return stiction[idx]; });   // stiction compensation model
    logger().addLogEntry("alphaF_" + std::to_string(idx), this, [this,idx]() { return alpha_filtered[idx]; });  // filtered joint velocity

    // live plots 
    gui()->addPlot
    (
      "DOF  "+std::to_string(idx) ,
      mc_rtc::gui::plot::X("t", [this]() { return t; }),
      mc_rtc::gui::plot::Y("desired torque", [this,idx]() { return cmdTau[idx]; }, Color::Blue),
      mc_rtc::gui::plot::Y("compensated torque", [this,idx]() { return cmdTau[idx]+stiction_bool*stiction[idx]+NN_bool*predicted_error[idx]; }, Color::Green),
      mc_rtc::gui::plot::Y("measured torque", [this,idx]() { return tau[idx]; }, Color::Red)
    );
    // PD gains tuning
    gui()->addElement
    (
      this, {"controller tuning", "proportionnal"},
      mc_rtc::gui::NumberSlider("K" + std::to_string(idx+1), [this,idx]() { return Kp(idx,idx); },
       [this,idx](double w){ Kp(idx,idx) = w; }, 0, 100  ) 
    );
    gui()->addElement
    (
      this, {"controller tuning", "derived"},
      mc_rtc::gui::NumberSlider("K" + std::to_string(idx+1), [this,idx]() { return Kd(idx,idx); },
       [this,idx](double w){ Kd(idx,idx) = w; }, 0, 10) 
    );
    // stiction copensation tuning
    gui()->addElement
    (
      this, {"stiction"},
      mc_rtc::gui::NumberSlider("s" + std::to_string(idx+1), [this,idx]() { return Fs[idx]; },
       [this,idx](double w){ Fs[idx] = w; }, 0, 10) 
    );
    // enable stiction compensation and NN compensation
    gui()->addElement
    (
      this, {"Compensation"},
      mc_rtc::gui::Button("Activate stiction compensation", [this]() { compensate_stiction = !compensate_stiction; }),
      mc_rtc::gui::Button("Activate NN compensation", [this]() { compensate_NN = !compensate_NN; })
    );
  }
  

  /* Load the Torch model */
  try 
  {
    module = torch::jit::load(path_to_model);
  }
  catch (const c10::Error& e) 
  {
    std::cerr << "error loading the model\n";
  }

  /* Initialize kortex connection */
  datastore().make<std::string>("ControlMode", "Torque");
  datastore().assign<std::string>("ControlMode","Torque");

}


bool KinovaReal::run()
{
  /*
  Structure of run method:
    * Call mc-rtc solver in open-loop
    * Update the state of the robot from measurements on the real system
    * Compute input torque using PD correction with desired posture
    * Compute residual
    * Feed the input to the LSTM model
    * Check if the posture target is met
    * Send torque command + compensation to the real robot
  */

  bool QPsolver = mc_control::MCController::run(mc_solver::FeedbackType::OpenLoop) ;

  observe();                          // Collect measurements from real robot
  compute_torque();                   // Compute desired torque using PD correction
  compute_residual();                 // Compute residual for comparison with the LSTM output

  if (sampler == 4)                   // Downsampling at 200 Hz f
  {
    feed_forward() ;                  // Feed measurements and desired torque to LSTM model
    sampler = 0 ;
  }
  if(postureTask->eval().norm() < 0.1)
  {
    switch_target();                  // Sample new desired posture
    iteration = 0;
  }

  // Send torque command + compensation to the robot
  if (compensate_stiction)
  {
    stiction_bool = 1;
  }
  else 
  {
    stiction_bool = 0;
  }
  if (compensate_NN)
  {
    NN_bool = 1;
  }
  else
  {
    NN_bool = 0;
  }
  rbd::vectorToParam(cmdTau+NN_bool*predicted_error+stiction_bool*stiction,robot().mbc().jointTorque); 

  t = t+T ;                          
  iteration++ ;                       
  sampler++ ;
  return QPsolver ;
}


void KinovaReal::compute_residual()
{
  /*
  Updates the residual based on the generalized momentum method
  p, r and integralTerm are vectors of size 7
  */
  Eigen::DiagonalMatrix<double, 7, 7> KI_matrix ;
  KI_matrix.diagonal() << KI,KI,KI,KI,KI,KI,KI ;
  if(t==0)
  {
    p = M*alpha ; 
    integralTerm.setZero();
  }
  auto Cmat =  coriolis->coriolis(realRobot().mb(), realRobot().mbc());
  integralTerm = integralTerm + T*(cmdTau  + (Cmat.transpose() + Cmat )* alpha - C + r) ;
  r = (KI_matrix*(M*alpha - integralTerm - p)) ;
}


void KinovaReal::reset(const mc_control::ControllerResetData & reset_data)
{
  mc_control::MCController::reset(reset_data);
  postureTask->reset() ;
}


void KinovaReal::compute_torque()
{
  /*
  Computes the desired torque
  Compute the compensation of stiction
  cmdTau and stiction size 7 vector 
  */

 // PD correction
  cmdTau = Kp*(q_d - q) + Kd*(alpha_d - alpha) + C;
  
  for (int i=0; i<7; i++)
  {
    if (abs(cmdTau[i])<1e-6)                                                          // saturation of the desired torque
    {                                                                                 // 
      cmdTau[i] = 0;                                                                  // avoid division by 0
    }                                                                                 //  
    else                                                                              //    
    {                                                                                 //  
      cmdTau[i] = ((cmdTau[i])/(abs(cmdTau[i])))*std::min(abs(cmdTau[i]),maxTau[i]);  // saturation 
    }                                                                                 //  
    cmdTau_filtered[i] = (1-EWMA) * cmdTau[i] + EWMA * cmdTau_filtered[i] ;           // low pass filtering of torque using EWMA filter

    if (abs(cmdTau_filtered[i]-C[i])<5*1e-2)                                        // if desired torque is close to gravity copensation
    {                                                                               // the robot should not move
      stiction[i] = 0;                                                              // thus stop stiction compensation
    }
    else if (abs(alpha_filtered[i])<5*1e-2)                                         // if real velocity is small but the robot should still move
    {                                                                               // the stiction compensation uses the sign of the desired
      stiction[i] = (cmdTau_filtered[i]-C[i])/abs(cmdTau_filtered[i]-C[i]) * Fs[i]; // acceleration computed from forward dynamics.
    }                                                                               
    else                                                                            // if the robot should be moving and is moving,
    {                                                                               // the stiction is compensated based on the sign of the real velocity of the joint
      stiction[i] = (alpha_filtered[i])/abs(alpha_filtered[i]) * Fs[i];
    }

  }
}


void KinovaReal::observe()
{
  /*
  Gather target trajectory from mc-rtc
  Gather measurements from real robot
  Convert targets and measurements to eigen vectors
  */

  // forward dynamics to get gravity coriolis vector and inertia matrix
  auto forwardDynamics = rbd::ForwardDynamics(robot().mb());
  forwardDynamics.computeC(realRobot().mb(),realRobot().mbc());
  forwardDynamics.computeH(realRobot().mb(),realRobot().mbc());
  C = forwardDynamics.C();
  M = forwardDynamics.H();

  // convert state targets and measurements to eigen vector
  rbd::paramToVector(robot().mbc().q,q_d) ;
  rbd::paramToVector(robot().mbc().alpha,alpha_d) ;
  rbd::paramToVector(robot().mbc().alphaD,acc_d) ;
  rbd::paramToVector(realRobot().mbc().q,q) ;
  rbd::paramToVector(realRobot().mbc().alpha,alpha) ;

  // filtering of velocity
  alpha_filtered = (1-EWMA) * alpha + EWMA * alpha_filtered ;
  for (int idx=0; idx<7; idx++)
  {
    // torque sensor measurements
    tau[idx] = realRobot().jointTorques()[idx] ; 
  }
  measured_error = cmdTau - tau; 
}


void KinovaReal::switch_target()
{
  /*
  Called when posture target is met
  Samples new target posture in joint space using uniform distribution
  Angles of joints 2 and 4 are bounded to prevent the robot from hitting its base 
  */

  std::mt19937 gen(rd());
  std::uniform_real_distribution<> dis(0.0, 1.0);
  for(int i=0; i<7; i++)
  {
    // q_obj in (qInf ; qSup)
    q_obj[i] = dis(gen) * (qSup[i]-qInf[i]) + qInf[i] ; 
  }
  PostureTarget = {
    {"joint_1",{q_obj[0]}},
    {"joint_2",{q_obj[1]}},
    {"joint_3",{q_obj[2]}},
    {"joint_4",{q_obj[3]}},
    {"joint_5",{q_obj[4]}},
    {"joint_6",{q_obj[5]}},
    {"joint_7",{q_obj[6]}},
  };
  postureTask->target(PostureTarget);
}


void KinovaReal::feed_forward()
{
  /* 
  Converts inputs from eigen to torch tensor
  Creates sequence of inputs
  Feeds the input to the LSTM model
  */

  auto options = torch::TensorOptions().dtype(torch::kFloat64);
  for (int l=1; l<10; l++)
  {
    x.index_put_({l-1},x.index({l})) ;
  }
  x.index_put_({9,Slice(0,7)},torch::from_blob(q.data(), {7}, options)) ;
  x.index_put_({9,Slice(7,14)},torch::from_blob(alpha.data(), {7}, options)) ;
  x.index_put_({9,Slice(14,21)},torch::from_blob(C.data(), {7}, options)) ;
  x.index_put_({9,Slice(21,28)},torch::from_blob(cmdTau.data(), {7}, options)) ;

  // wait until the first sequence is complete (50 ms) before feeding it to the network
  if (iteration>5*10)
  {
    std::vector<torch::jit::IValue> inputs;
    inputs.push_back(x);
    at::Tensor output = module.forward(inputs).toTensor().index({9}) ;
    for(int i=0; i<7; i++)
    {
      predicted_error[i] = output.index({i}).item<double>() ;
    }
  }
}



CONTROLLER_CONSTRUCTOR("KinovaReal", KinovaReal)
