#pragma once

#include <torch/script.h> // One-stop header.
#include <memory>
#include <iostream>
#include <Eigen/Dense>
#include <mc_control/mc_controller.h>
#include <mc_tasks/EndEffectorTask.h>
#include <mc_tasks/PostureTask.h>
#include <RBDyn/Coriolis.h>
#include <mc_rtc/gui/plot.h>
#include <mc_rbdyn/RobotLoader.h>
#include <mc_observers/EncoderObserver.h>
#include <math.h>
#include <random>
#include "api.h"

using Color = mc_rtc::gui::Color;
using PolygonDescription = mc_rtc::gui::plot::PolygonDescription;
using Range = mc_rtc::gui::plot::Range;
using Style = mc_rtc::gui::plot::Style;
using Side = mc_rtc::gui::plot::Side;
using namespace torch::indexing ;


struct KinovaReal_DLLAPI KinovaReal : public mc_control::MCController
{
  KinovaReal(mc_rbdyn::RobotModulePtr rm, double dt, const mc_rtc::Configuration & config);

  bool run() override;

  void reset(const mc_control::ControllerResetData & reset_data) override;

  void compute_torque();

  void compute_residual();

  void switch_target();

  void feed_forward();

  void observe();


private:
    std::string path_to_model = "/home/gabinlembrez/trained_nets/cpp_export/trained_model.pt" ; // path to model weights 
    std::map<std::string,std::vector<double>> PostureTarget ;                                   // desired posture (joint space)
    std::random_device rd;                                                                      // random device for sampling posture

    bool compensate_stiction = false;                     // enables stiction compensation
    bool compensate_NN       = false;                     // enables NN driven compensation

    rbd::Coriolis * coriolis ;                            // coriolis centrifugal matrix
    
    torch::jit::script::Module module;                    // format for libtorch model
    torch::Tensor x = torch::zeros({10,28}).cuda() ;      // input of the model


    int iteration = 0;                                    // counts all iteration
    int sampler = 0;                                      // used for sampling every 5 iteration
    int stiction_bool=0;                                  // activates stiction
    int NN_bool=0;                                        // activates NN correction

    double PI = mc_rtc::constants::PI ;                   // pi
    double t = 0 ;                                        // real time
    double T = 0.001 ;                                    // timestep
    double EWMA = 0.999 ;                                 // low pass filter parameter
    double KI = 5;                                        // gain of residual 

    double qInf[7] = {-PI,-2*PI/5,-PI,-PI/2,-PI,-2,-PI} ; // limits of the joints
    double qSup[7] = {PI,2*PI/5,PI,PI/2,PI,2,PI} ;        //    

    Eigen::Matrix<double, 7, 7> M ;                       // Mass-inertia matrix
    Eigen::Matrix<double, 7, 7> I ;                       // rotor inertia diagonal matrix
    Eigen::Matrix<double, 7, 7> Kp ;                      // proportional gain
    Eigen::Matrix<double, 7, 7> Kd ;                      // derivative gain
    Eigen::Matrix<double, 7, 1> C ;                       // gravity coriolis vector
    Eigen::Matrix<double, 7, 1> q ;                       // state of the real robot
    Eigen::Matrix<double, 7, 1> r ;                       // residual (generalized momentum observer)
    Eigen::Matrix<double, 7, 1> p ;                       // generalized omentum
    Eigen::Matrix<double, 7, 1> g;                        // gravity vector
    Eigen::Matrix<double, 7, 1> integralTerm ;            // provisory term for residual computation
    Eigen::Matrix<double, 7, 1> alpha ;                   // real joint velocity
    Eigen::Matrix<double, 7, 1> alpha_filtered ;          // filtered real joint velocity
    Eigen::Matrix<double, 7, 1> q_d ;                     // desired position of the joints
    Eigen::Matrix<double, 7, 1> alpha_d ;                 // desired velocity of the joints
    Eigen::Matrix<double, 7, 1> acc_d ;                   // desired angular accleration of the joints
    Eigen::Matrix<double, 7, 1> cmdTau ;                  // desired torque 
    Eigen::Matrix<double, 7, 1> cmdTau_filtered ;         // filtered desired torque
    Eigen::Matrix<double, 7, 1> tau ;                     // measured torque
    Eigen::Matrix<double, 7, 1> predicted_error;          // torque error estimated by the neural network
    Eigen::Matrix<double, 7, 1> measured_error ;          // torque error measured by the torque sensors
    Eigen::Matrix<double, 7, 1> maxTau ;                  // torque limit in the joints
    Eigen::Matrix<double, 7, 1> q_obj ;                   // desired position (vector)
    Eigen::Matrix<double, 7, 1> stiction ;                // compensation of stiction
    Eigen::Matrix<double, 7, 1> Fs ;                      // minimum torque to overcome stiction
};