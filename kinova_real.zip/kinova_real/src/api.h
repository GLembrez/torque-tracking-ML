#pragma once

#if defined _WIN32 || defined __CYGWIN__
#  define KinovaReal_DLLIMPORT __declspec(dllimport)
#  define KinovaReal_DLLEXPORT __declspec(dllexport)
#  define KinovaReal_DLLLOCAL
#else
// On Linux, for GCC >= 4, tag symbols using GCC extension.
#  if __GNUC__ >= 4
#    define KinovaReal_DLLIMPORT __attribute__((visibility("default")))
#    define KinovaReal_DLLEXPORT __attribute__((visibility("default")))
#    define KinovaReal_DLLLOCAL __attribute__((visibility("hidden")))
#  else
// Otherwise (GCC < 4 or another compiler is used), export everything.
#    define KinovaReal_DLLIMPORT
#    define KinovaReal_DLLEXPORT
#    define KinovaReal_DLLLOCAL
#  endif // __GNUC__ >= 4
#endif // defined _WIN32 || defined __CYGWIN__

#ifdef KinovaReal_STATIC
// If one is using the library statically, get rid of
// extra information.
#  define KinovaReal_DLLAPI
#  define KinovaReal_LOCAL
#else
// Depending on whether one is building or using the
// library define DLLAPI to import or export.
#  ifdef KinovaReal_EXPORTS
#    define KinovaReal_DLLAPI KinovaReal_DLLEXPORT
#  else
#    define KinovaReal_DLLAPI KinovaReal_DLLIMPORT
#  endif // KinovaReal_EXPORTS
#  define KinovaReal_LOCAL KinovaReal_DLLLOCAL
#endif // KinovaReal_STATIC